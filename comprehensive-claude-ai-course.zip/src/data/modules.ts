import type { Module } from '../types';

export const modules: Module[] = [
  // ======================================================================
  // MODULE 1
  // ======================================================================
  {
    id: 'm1',
    title: 'Meet Claude',
    subtitle: 'What Claude is, who makes it, and why it matters',
    icon: '👋',
    color: 'from-orange-400 to-amber-500',
    lessons: [
      {
        id: 'm1l1',
        title: 'What is Claude?',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Claude is a family of large language models (LLMs) built by Anthropic, an AI safety company founded in 2021 by former OpenAI researchers, including siblings Dario and Daniela Amodei. Claude is designed to be helpful, harmless, and honest — a philosophy that shapes everything from how it answers questions to how it refuses unsafe requests.' },
          { type: 'paragraph', text: 'At its core, Claude is a next-word-prediction engine trained on enormous amounts of text, then fine-tuned with human feedback and a technique called Constitutional AI so that it behaves in line with a set of values rather than just raw internet data.' },
          { type: 'list', items: [
            'Claude can read and write text, analyze images, read documents (PDFs, spreadsheets), and write/execute code.',
            'Claude is accessible through claude.ai (web/desktop/mobile apps), the Anthropic API, and major cloud platforms (AWS Bedrock, Google Vertex AI).',
            'Claude is named after Claude Shannon, the father of information theory.',
          ] },
          { type: 'tip', title: 'Why "Claude" matters', text: 'Unlike a search engine, Claude does not look things up by default — it generates answers from patterns learned during training (plus any tools/search you explicitly give it). Understanding this is key to using it well.' },
        ],
        keyTakeaways: [
          'Claude is an LLM-based AI assistant created by Anthropic.',
          'It is built around being helpful, harmless, and honest.',
          'It can work with text, images, documents, and code.',
        ],
      },
      {
        id: 'm1l2',
        title: 'The Claude model family',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Anthropic ships Claude in different sizes so you can trade off speed, cost, and intelligence depending on your task. The naming convention uses a "weight class" metaphor.' },
          { type: 'list', items: [
            'Haiku — the fastest and most affordable tier. Great for high-volume, simple tasks like classification, extraction, or chat support.',
            'Sonnet — the balanced, workhorse tier. Strong reasoning and coding ability at a moderate price — the most commonly used tier for everyday work.',
            'Opus — the most capable tier. Best for the hardest reasoning, research, and complex multi-step agentic tasks, at a higher cost and lower speed.',
          ] },
          { type: 'paragraph', text: 'Each tier is versioned (for example 3, 3.5, 3.7, 4, 4.5) — newer versions generally improve reasoning, coding, instruction-following, and reduce hallucinations. Many Claude models also support "extended thinking," where the model reasons step-by-step before answering, boosting accuracy on hard problems.' },
          { type: 'tip', text: 'Rule of thumb: start with Sonnet for most tasks. Drop to Haiku if you need speed/scale. Reach for Opus when a task really needs maximum reasoning quality.' },
        ],
        keyTakeaways: [
          'Claude comes in tiers: Haiku (fast/cheap), Sonnet (balanced), Opus (most capable).',
          'Higher version numbers mean better reasoning, coding, and accuracy.',
          'Extended thinking lets some Claude models reason before answering.',
        ],
      },
      {
        id: 'm1l3',
        title: 'How Claude is different from other AI tools',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Many general-purpose AI chatbots are built on similar underlying technology (transformer-based LLMs), but they differ in training data, fine-tuning philosophy, and product features.' },
          { type: 'list', items: [
            'Safety-first design: Anthropic trains Claude using Constitutional AI — a method where the model critiques and revises its own answers against a written set of principles instead of relying purely on human labelers.',
            'Long context windows: Claude can hold very large amounts of text in a single conversation (hundreds of thousands of tokens on many models), great for analyzing whole books, codebases, or legal contracts.',
            'Artifacts: claude.ai can generate living, editable outputs — such as a working webpage, diagram, or document — in a separate pane you can preview and iterate on.',
            'Claude Code: a terminal-based agentic coding tool that lets Claude read, write, and run code directly in your dev environment.',
            'Strong writing & reasoning style: Claude is often praised for nuanced, well-structured prose and careful, step-by-step reasoning.',
          ] },
          { type: 'quote', text: 'The best way to think of Claude is less like a search engine and more like an extremely well-read, careful collaborator who needs clear instructions.' },
        ],
        keyTakeaways: [
          'Claude emphasizes safety via Constitutional AI.',
          'Large context windows let Claude work with huge documents.',
          'Unique features like Artifacts and Claude Code set it apart.',
        ],
      },
    ],
    quiz: {
      id: 'm1q',
      title: 'Module 1 Check: Meet Claude',
      passPercent: 70,
      questions: [
        {
          id: 'm1q1',
          question: 'Who created Claude?',
          options: ['Google DeepMind', 'Anthropic', 'OpenAI', 'Meta AI'],
          correctIndex: 1,
          explanation: 'Claude is developed by Anthropic, an AI safety company founded in 2021.',
        },
        {
          id: 'm1q2',
          question: 'Which training approach is most associated with shaping Claude\'s values and safety behavior?',
          options: ['Constitutional AI', 'Random forest tuning', 'Keyword filtering only', 'Manual rule hardcoding'],
          correctIndex: 0,
          explanation: 'Constitutional AI lets the model critique and revise its own responses against a written set of principles.',
        },
        {
          id: 'm1q3',
          question: 'Which Claude tier is designed to be the fastest and most cost-effective?',
          options: ['Opus', 'Sonnet', 'Haiku', 'Ultra'],
          correctIndex: 2,
          explanation: 'Haiku is the smallest, fastest and cheapest tier, ideal for high-volume simple tasks.',
        },
        {
          id: 'm1q4',
          question: 'What is "extended thinking" in Claude?',
          options: [
            'A longer chat history limit',
            'A mode where Claude reasons step-by-step internally before giving a final answer',
            'A way to make responses longer in words',
            'A plugin for grammar checking',
          ],
          correctIndex: 1,
          explanation: 'Extended thinking allows the model to work through a problem step by step before producing its final answer, improving accuracy on hard tasks.',
        },
        {
          id: 'm1q5',
          question: 'What is Claude named after?',
          options: ['A programming language', 'Claude Shannon, father of information theory', 'The Anthropic CEO\'s first name', 'A Greek mythological figure'],
          correctIndex: 1,
          explanation: 'Claude is named after Claude Shannon, a pioneer of information theory.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 2
  // ======================================================================
  {
    id: 'm2',
    title: 'Getting Started',
    subtitle: 'Setting up and navigating claude.ai, apps, and core features',
    icon: '🚀',
    color: 'from-amber-400 to-orange-500',
    lessons: [
      {
        id: 'm2l1',
        title: 'Where you can use Claude',
        minutes: 6,
        blocks: [
          { type: 'list', items: [
            'claude.ai — the official web app (also available as desktop and mobile apps) with chat, Projects, Artifacts, and file uploads.',
            'Anthropic API (console.anthropic.com) — lets developers integrate Claude into their own apps and products.',
            'Cloud marketplaces — Claude is available via Amazon Bedrock, Google Cloud Vertex AI, and Microsoft Foundry for enterprise deployments.',
            'Claude Code — a command-line tool for agentic software development directly in your terminal/IDE.',
            'Third-party apps — many products (writing tools, customer support platforms, IDE extensions like Claude for VS Code / JetBrains) embed Claude under the hood.',
          ] },
          { type: 'tip', text: 'For this course we will focus mainly on claude.ai (for everyday use) and the API/Claude Code (for building things), since together they cover the whole beginner-to-professional journey.' },
        ],
        keyTakeaways: [
          'Claude is available through a consumer web/app product and a developer API.',
          'Enterprises can access Claude via major cloud platforms.',
          'Claude Code brings Claude into the terminal for coding tasks.',
        ],
      },
      {
        id: 'm2l2',
        title: 'The claude.ai interface',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'When you sign up at claude.ai you get a simple chat interface. A few key building blocks:' },
          { type: 'list', items: [
            'New chat — starts a fresh conversation with no memory of previous chats (unless you turn on cross-chat memory features where available).',
            'Model selector — choose which Claude model/tier powers your conversation.',
            'Projects — a workspace that bundles custom instructions, uploaded knowledge files, and all chats related to one goal (e.g. "Marketing Q3" or "My Novel").',
            'Artifacts — a side panel that opens automatically when Claude produces a substantial, self-contained output like code, a webpage, a diagram, or a document, so you can view/iterate on it separately from the conversation.',
            'Styles — tone presets (e.g. Normal, Concise, Explanatory, Formal) that change how Claude writes without you having to re-explain your preferences every time.',
            'Attachments — upload images, PDFs, spreadsheets, or text files directly into a chat for Claude to analyze.',
          ] },
          { type: 'tip', title: 'Pro habit', text: 'Use Projects for anything recurring. It saves you from repeating context and keeps related chats organized in one place.' },
        ],
        keyTakeaways: [
          'Projects group related chats with shared instructions and files.',
          'Artifacts let you preview/iterate on generated content separately.',
          'Styles let you control tone without re-explaining preferences.',
        ],
      },
      {
        id: 'm2l3',
        title: 'Your first conversation',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'The fastest way to learn Claude is to use it. Try starting with small, clear tasks before moving to complex ones.' },
          { type: 'list', items: [
            'Ask Claude to summarize an article you paste in.',
            'Ask Claude to explain a concept "like I\'m a beginner" vs "like I\'m an expert" and compare the answers.',
            'Upload a PDF and ask Claude specific questions about it.',
            'Ask Claude to write a short Python script, then ask it to improve or explain the script.',
          ] },
          { type: 'warning', title: 'Remember', text: 'Claude can make mistakes, especially with very specific facts, dates, citations, or niche numeric calculations. Always verify anything important before relying on it.' },
        ],
        keyTakeaways: [
          'Hands-on experimentation is the best way to build intuition.',
          'Start simple, then layer in complexity.',
          'Always verify high-stakes or factual outputs.',
        ],
      },
    ],
    quiz: {
      id: 'm2q',
      title: 'Module 2 Check: Getting Started',
      passPercent: 70,
      questions: [
        {
          id: 'm2q1',
          question: 'What is the purpose of "Projects" on claude.ai?',
          options: [
            'To bill your account per task',
            'To bundle custom instructions, files, and chats around one goal',
            'To automatically publish your chats online',
            'To switch between different AI companies',
          ],
          correctIndex: 1,
          explanation: 'Projects let you organize shared context, instructions, and knowledge files around a recurring goal.',
        },
        {
          id: 'm2q2',
          question: 'What triggers the Artifacts panel to open?',
          options: [
            'Every single message Claude sends',
            'Only when you type the word "artifact"',
            'When Claude produces a substantial, self-contained piece of content like code or a document',
            'When you upgrade your subscription',
          ],
          correctIndex: 2,
          explanation: 'Artifacts open for standalone generated content so you can preview and iterate on it separately.',
        },
        {
          id: 'm2q3',
          question: 'Which of these is NOT a way to access Claude?',
          options: ['claude.ai web app', 'Anthropic API', 'Amazon Bedrock', 'Direct brain-computer interface'],
          correctIndex: 3,
          explanation: 'Claude is accessed via apps, the API, and cloud platforms — not brain-computer interfaces!',
        },
        {
          id: 'm2q4',
          question: 'What should you always do with important factual outputs from Claude?',
          options: ['Trust them blindly', 'Ignore them entirely', 'Verify them independently', 'Only use them in Haiku mode'],
          correctIndex: 2,
          explanation: 'LLMs can make mistakes, so verifying important facts is essential professional practice.',
        },
        {
          id: 'm2q5',
          question: '"Styles" on claude.ai are primarily used to:',
          options: [
            'Change the color theme of the app',
            'Control Claude\'s tone/voice without re-explaining preferences each time',
            'Select which programming language Claude writes in',
            'Switch between chat and voice mode',
          ],
          correctIndex: 1,
          explanation: 'Styles are tone presets like Concise, Explanatory, or Formal.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 3
  // ======================================================================
  {
    id: 'm3',
    title: 'Prompt Engineering Fundamentals',
    subtitle: 'The core skill: writing prompts that get great results',
    icon: '✍️',
    color: 'from-yellow-400 to-amber-600',
    lessons: [
      {
        id: 'm3l1',
        title: 'Be clear and direct',
        minutes: 8,
        blocks: [
          { type: 'paragraph', text: 'Claude performs best when instructions are explicit. Treat Claude like a brilliant new hire who is eager to help but has zero context about your unwritten assumptions — spell things out.' },
          { type: 'list', items: [
            'State the task plainly: what do you want, in what format, for what audience?',
            'Give context: why you need it, who will read/use it, what "good" looks like.',
            'Specify constraints: length, tone, structure, things to avoid.',
            'Break complex asks into numbered steps.',
          ] },
          { type: 'compare', bad: 'Write about dogs.', good: 'Write a 150-word friendly blog intro about why Labrador Retrievers make great family pets, aimed at first-time dog owners. Avoid clichés like "man\'s best friend."' },
          { type: 'tip', text: 'A useful test: if you handed your prompt to a competent stranger with no other context, could they produce exactly what you want? If not, add detail.' },
        ],
        keyTakeaways: [
          'Vague prompts produce vague, generic answers.',
          'Give task, context, format, audience, and constraints.',
          'Specificity is the single highest-leverage prompting skill.',
        ],
      },
      {
        id: 'm3l2',
        title: 'Assigning roles (system prompts & persona)',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'You can tell Claude to adopt a role or persona — this is often called "role prompting." It shapes vocabulary, focus, and depth of the response. In the API, this is usually set via the system prompt, which defines Claude\'s overall role/behaviour for the whole conversation.' },
          { type: 'code', language: 'text', code: 'System: You are a senior backend engineer who reviews code for security vulnerabilities. Be terse and technical. Always point to the specific line number.' },
          { type: 'paragraph', text: 'Role prompting is powerful for:' },
          { type: 'list', items: [
            'Expertise framing — "You are a tax accountant specializing in freelancers in the UK."',
            'Audience framing — "Explain this to a curious 10-year-old."',
            'Tone/format control — "You are a strict copy editor who only returns a bullet list of fixes."',
          ] },
          { type: 'tip', text: 'Combine role + task + format for the best results: who Claude should "be," what to do, and how to present it.' },
        ],
        keyTakeaways: [
          'System prompts set Claude\'s persistent role/behaviour for a conversation.',
          'Role prompting changes vocabulary, depth, and focus.',
          'Combine role + task + output format for best results.',
        ],
      },
      {
        id: 'm3l3',
        title: 'Using examples (few-shot prompting)',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Showing Claude 2-5 examples of the input/output pattern you want ("few-shot prompting") is one of the most reliable ways to control style, format, and edge-case handling — often more effective than long written descriptions.' },
          { type: 'code', language: 'text', code: 'Convert customer messages into a JSON sentiment label.\n\nExample 1\nInput: "This product changed my life!"\nOutput: {"sentiment": "positive"}\n\nExample 2\nInput: "It broke after two days, awful."\nOutput: {"sentiment": "negative"}\n\nNow classify:\nInput: "It\'s okay, does the job."\nOutput:' },
          { type: 'tip', text: 'Make your examples diverse and representative of tricky edge cases, not just easy ones — Claude will mirror the patterns you show it, including any flaws.' },
        ],
        keyTakeaways: [
          'Few-shot examples teach format and style more reliably than instructions alone.',
          'Use 2-5 high-quality, diverse examples.',
          'Claude mirrors the patterns in your examples — including mistakes.',
        ],
      },
      {
        id: 'm3l4',
        title: 'Structuring prompts with XML tags',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Claude was trained to pay special attention to XML-style tags (e.g. <document>, <instructions>, <example>). Using tags to separate different parts of a long prompt dramatically reduces confusion between "data" and "instructions."' },
          { type: 'code', language: 'text', code: '<document>\n{{paste long report here}}\n</document>\n\n<instructions>\nSummarize the document above in 3 bullet points for a non-technical executive.\nDo not include numbers that are not explicitly in the document.\n</instructions>' },
          { type: 'list', items: [
            'Tags can be anything descriptive: <context>, <question>, <tone>, <output_format>.',
            'Tags help Claude (and you!) keep long, multi-part prompts organized.',
            'Especially useful when mixing reference material with instructions.',
          ] },
        ],
        keyTakeaways: [
          'XML tags cleanly separate instructions from content/data.',
          'This reduces ambiguity in long or multi-part prompts.',
          'Tag names can be descriptive and custom — there is no fixed schema.',
        ],
      },
      {
        id: 'm3l5',
        title: 'Letting Claude think: chain-of-thought',
        minutes: 8,
        blocks: [
          { type: 'paragraph', text: 'For tasks involving math, logic, multi-step reasoning, or analysis, asking Claude to "think step by step" before answering (chain-of-thought prompting) substantially improves accuracy — it gives the model room to work through the problem instead of jumping straight to a guess.' },
          { type: 'code', language: 'text', code: 'Before answering, think through the problem step-by-step inside <thinking> tags. Then give your final answer inside <answer> tags.' },
          { type: 'paragraph', text: 'Some Claude models also support built-in "extended thinking," a dedicated reasoning mode you can enable via the API or in the claude.ai model selector, which lets Claude allocate more internal reasoning before answering difficult questions.' },
          { type: 'tip', text: 'Reserve chain-of-thought for genuinely hard problems. For simple tasks it just adds latency and cost without improving quality.' },
        ],
        keyTakeaways: [
          'Asking Claude to reason step-by-step improves accuracy on hard problems.',
          'Extended thinking is a built-in reasoning mode on supported models.',
          'Don\'t overuse chain-of-thought on simple tasks.',
        ],
      },
    ],
    quiz: {
      id: 'm3q',
      title: 'Module 3 Check: Prompt Engineering Fundamentals',
      passPercent: 70,
      questions: [
        {
          id: 'm3q1',
          question: 'Which prompt is more likely to get a high-quality, specific result?',
          options: [
            '"Write something about marketing."',
            '"Write a 100-word LinkedIn post about why small businesses should invest in email marketing, written in a confident but friendly tone."',
            '"Marketing tips please."',
            '"Tell me stuff."',
          ],
          correctIndex: 1,
          explanation: 'Specific prompts with task, format, length, audience, and tone produce far better results.',
        },
        {
          id: 'm3q2',
          question: 'In the API, which component sets Claude\'s persistent role/persona for a whole conversation?',
          options: ['The user message', 'The system prompt', 'The temperature parameter', 'The max_tokens field'],
          correctIndex: 1,
          explanation: 'The system prompt defines the role, behaviour and ground rules for the whole conversation.',
        },
        {
          id: 'm3q3',
          question: 'What is "few-shot prompting"?',
          options: [
            'Giving Claude very short prompts',
            'Providing a handful of input/output examples to demonstrate the desired pattern',
            'Limiting Claude to a few words in its answer',
            'Running the same prompt multiple times',
          ],
          correctIndex: 1,
          explanation: 'Few-shot prompting shows Claude examples of the exact input/output pattern you want.',
        },
        {
          id: 'm3q4',
          question: 'Why use XML tags like <document> and <instructions> in a prompt?',
          options: [
            'They make the prompt shorter',
            'Claude requires valid HTML to respond',
            'They help clearly separate data from instructions, reducing ambiguity',
            'They are required for every prompt to work at all',
          ],
          correctIndex: 2,
          explanation: 'XML tags organize long prompts and help Claude distinguish reference content from instructions.',
        },
        {
          id: 'm3q5',
          question: 'When is chain-of-thought ("think step by step") prompting most useful?',
          options: [
            'For simple one-word answers',
            'For complex reasoning, math, or multi-step analysis tasks',
            'Only when generating images',
            'Never — it always hurts performance',
          ],
          correctIndex: 1,
          explanation: 'Chain-of-thought prompting gives Claude room to reason, which helps most on hard, multi-step problems.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 4
  // ======================================================================
  {
    id: 'm4',
    title: 'Advanced Prompting Techniques',
    subtitle: 'Prompt chaining, reducing hallucination, and iteration',
    icon: '🧠',
    color: 'from-orange-500 to-red-500',
    lessons: [
      {
        id: 'm4l1',
        title: 'Prompt chaining',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Complex tasks often work better when broken into a chain of smaller prompts, where the output of one step becomes the input of the next, rather than one giant mega-prompt.' },
          { type: 'list', items: [
            'Step 1: Ask Claude to extract key facts from a document.',
            'Step 2: Ask Claude to draft an analysis using only those facts.',
            'Step 3: Ask Claude to critique and improve its own draft.',
          ] },
          { type: 'tip', text: 'This also makes debugging easier — if the final output is wrong, you can inspect each intermediate step to find where it went off track.' },
        ],
        keyTakeaways: [
          'Breaking big tasks into chained prompts improves reliability.',
          'Each step\'s output feeds the next step\'s input.',
          'Chaining makes it easier to debug where errors occur.',
        ],
      },
      {
        id: 'm4l2',
        title: 'Reducing hallucinations',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Hallucination is when a model confidently states something false. No LLM is immune, but you can significantly reduce the risk.' },
          { type: 'list', items: [
            'Ground Claude in your own source material — paste in the actual document/data instead of relying on its memory.',
            'Explicitly permit uncertainty: "If you don\'t know or the document doesn\'t say, respond \'not stated\' instead of guessing."',
            'Ask for citations/quotes from the provided text to support claims.',
            'Use lower temperature (more deterministic output) for factual tasks.',
            'Ask Claude to double-check its own answer in a follow-up prompt.',
          ] },
          { type: 'warning', title: 'Never forget', text: 'Even with all these techniques, verify anything high-stakes (medical, legal, financial, safety-critical) with authoritative sources.' },
        ],
        keyTakeaways: [
          'Grounding answers in provided source text reduces hallucination.',
          'Explicitly allowing "I don\'t know" responses helps.',
          'Always independently verify high-stakes claims.',
        ],
      },
      {
        id: 'm4l3',
        title: 'Iterating and giving feedback',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Prompting is rarely "one and done" for important work — treat it like a conversation with a collaborator you can coach.' },
          { type: 'list', items: [
            'If the output is close but not quite right, tell Claude specifically what to change rather than starting over.',
            'Use phrases like "Keep the structure but make the tone more casual" or "This is too long — cut it to 100 words, keep point 2 and 3."',
            'Ask Claude to generate 2-3 variations so you can pick a direction before refining.',
            'For recurring tasks, save your best-performing prompt as a template.',
          ] },
        ],
        keyTakeaways: [
          'Iterative refinement beats trying to write the "perfect" prompt the first time.',
          'Give specific, targeted feedback on what to change.',
          'Save effective prompts as reusable templates.',
        ],
      },
      {
        id: 'm4l4',
        title: 'Prefilling and output control',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'When using the API, you can "prefill" the start of Claude\'s response to steer format or skip preamble (e.g., forcing it to start directly with JSON or skip a conversational intro like "Sure, here is...").' },
          { type: 'code', language: 'text', code: 'User: List 3 risks of this contract clause as JSON.\nAssistant (prefill): {' },
          { type: 'paragraph', text: 'You can also directly request output constraints in plain language: "Respond with only the corrected sentence, no explanation" or "Output valid JSON matching this schema, nothing else."' },
          { type: 'tip', text: 'Being explicit about what NOT to include (no preamble, no apologies, no markdown) is often just as important as saying what you want.' },
        ],
        keyTakeaways: [
          'Prefilling the assistant turn can force a specific output format via the API.',
          'State both what to include and what to exclude.',
          'Precise output control matters a lot for programmatic use cases.',
        ],
      },
    ],
    quiz: {
      id: 'm4q',
      title: 'Module 4 Check: Advanced Prompting',
      passPercent: 70,
      questions: [
        {
          id: 'm4q1',
          question: 'What is "prompt chaining"?',
          options: [
            'Linking multiple Claude accounts together',
            'Breaking a complex task into a sequence of smaller prompts where outputs feed the next step',
            'Repeating the exact same prompt several times',
            'Connecting Claude to a blockchain',
          ],
          correctIndex: 1,
          explanation: 'Prompt chaining sequences smaller, focused prompts to reliably accomplish a complex task.',
        },
        {
          id: 'm4q2',
          question: 'Which technique most directly helps reduce hallucinations when summarizing a document?',
          options: [
            'Asking Claude to just use its general knowledge instead of the document',
            'Pasting the actual source document in and asking Claude to only use that content',
            'Increasing the temperature to maximum',
            'Avoiding any instructions at all',
          ],
          correctIndex: 1,
          explanation: 'Grounding Claude in the actual source material reduces made-up facts.',
        },
        {
          id: 'm4q3',
          question: 'What is "prefilling" in the context of the Claude API?',
          options: [
            'Pre-loading your account with credits',
            'Starting the assistant\'s response for it to steer format/content',
            'Filling out a form before using the API',
            'Caching previous answers',
          ],
          correctIndex: 1,
          explanation: 'Prefilling means supplying the beginning of Claude\'s reply to control the output format.',
        },
        {
          id: 'm4q4',
          question: 'Best practice when an output is "almost right" but not perfect?',
          options: [
            'Start a completely new conversation from scratch every time',
            'Give specific, targeted feedback about what to change',
            'Give up and do it manually',
            'Repeat the exact same prompt again unchanged',
          ],
          correctIndex: 1,
          explanation: 'Targeted iterative feedback is much more efficient than starting over or repeating unchanged prompts.',
        },
        {
          id: 'm4q5',
          question: 'For high-stakes domains like medical or legal advice, what should you always do with Claude\'s output?',
          options: [
            'Publish it immediately as-is',
            'Independently verify it with authoritative sources',
            'Assume it is always 100% correct',
            'Ask Claude to swear it is correct',
          ],
          correctIndex: 1,
          explanation: 'No LLM is immune to hallucination — high-stakes claims must be independently verified.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 5
  // ======================================================================
  {
    id: 'm5',
    title: "Claude's Features & Capabilities",
    subtitle: 'Vision, Artifacts, Projects, web search, and computer use',
    icon: '🧩',
    color: 'from-rose-400 to-orange-500',
    lessons: [
      {
        id: 'm5l1',
        title: 'Vision: understanding images',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Claude can analyze images — photos, screenshots, charts, diagrams, handwriting, and more. You can upload one or multiple images and ask questions about them.' },
          { type: 'list', items: [
            'Describe or caption an image.',
            'Extract text from a screenshot or scanned document (OCR-like reading).',
            'Interpret charts/graphs and summarize trends.',
            'Review a UI design/mockup and suggest improvements.',
            'Compare two images and spot differences.',
          ] },
          { type: 'tip', text: 'For best results with charts or dense images, ask specific questions ("What was the revenue in Q3?") rather than a vague "What is this?"' },
        ],
        keyTakeaways: [
          'Claude can interpret photos, screenshots, charts, and diagrams.',
          'Multiple images can be analyzed together in one prompt.',
          'Specific questions yield better results than vague ones.',
        ],
      },
      {
        id: 'm5l2',
        title: 'Artifacts: build and preview live outputs',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Artifacts turn Claude into a lightweight builder. When you ask for something like a webpage, React component, SVG diagram, or formatted document, Claude can generate it in a dedicated side panel you can view, edit instructions for, and iterate on live — without cluttering the chat.' },
          { type: 'list', items: [
            'Interactive prototypes: landing pages, simple games, calculators, dashboards.',
            'Diagrams: flowcharts, mind maps, org charts using Mermaid syntax.',
            'Documents: formatted reports, slide-style content.',
            'Data visualizations: charts built from data you provide.',
          ] },
          { type: 'tip', text: 'Ask Claude to "update the artifact" rather than regenerating from scratch when making small tweaks — this preserves what already works.' },
        ],
        keyTakeaways: [
          'Artifacts render standalone, iterable outputs like code and diagrams.',
          'Great for prototyping webpages, visualizations, and documents.',
          'Ask for incremental updates instead of full regenerations.',
        ],
      },
      {
        id: 'm5l3',
        title: 'Projects and custom knowledge',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Projects let you create a dedicated workspace with:' },
          { type: 'list', items: [
            'Custom instructions that apply to every chat in the project (e.g., "Always write in British English and cite sources").',
            'Uploaded knowledge files (docs, spreadsheets, PDFs, code) that Claude can reference across every chat in that project.',
            'A clean history of all conversations related to that specific goal.',
          ] },
          { type: 'tip', text: 'Use one Project per ongoing initiative: "Client X Onboarding," "Personal Finance," "Novel Draft," etc. This avoids re-uploading files or re-explaining context every session.' },
        ],
        keyTakeaways: [
          'Projects combine persistent instructions, files, and chat history.',
          'They eliminate repetitive context-setting.',
          'Best used for recurring, well-defined goals.',
        ],
      },
      {
        id: 'm5l4',
        title: 'Web search, tools, and extensions',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'By default, Claude\'s knowledge comes from training data with a cutoff date — it does not automatically know about events after that date unless given tools.' },
          { type: 'list', items: [
            'Web search: when enabled, Claude can search the live web and cite sources for up-to-date answers.',
            'Google Workspace / other integrations: some plans let Claude read your docs, calendar, or email with permission, to help with real tasks.',
            'Code execution: Claude can write and run code in a sandbox to verify calculations or produce charts.',
            'Model Context Protocol (MCP): an open standard that lets Claude connect to external tools, databases, and services in a structured way (more in Module 7).',
          ] },
          { type: 'warning', text: 'Tool access varies by plan and platform — always check which tools are enabled in your specific Claude setup.' },
        ],
        keyTakeaways: [
          'Claude\'s base knowledge has a training cutoff date.',
          'Enabling tools like web search extends Claude beyond its training data.',
          'MCP is a standard for connecting Claude to external systems.',
        ],
      },
    ],
    quiz: {
      id: 'm5q',
      title: 'Module 5 Check: Features & Capabilities',
      passPercent: 70,
      questions: [
        {
          id: 'm5q1',
          question: 'Which of these can Claude do with an uploaded image?',
          options: [
            'Only tell you the file size',
            'Describe it, extract text, interpret charts, and compare it to other images',
            'Nothing — Claude cannot process images at all',
            'Only convert it to black and white',
          ],
          correctIndex: 1,
          explanation: 'Claude has vision capabilities including description, OCR-like text extraction, and chart interpretation.',
        },
        {
          id: 'm5q2',
          question: 'What is the main purpose of the Artifacts feature?',
          options: [
            'To delete old chats automatically',
            'To render and let you iterate on standalone outputs like code, webpages, or diagrams',
            'To limit the number of messages you can send',
            'To translate Claude into other languages',
          ],
          correctIndex: 1,
          explanation: 'Artifacts provide a live, editable preview pane for generated content.',
        },
        {
          id: 'm5q3',
          question: 'What do Projects on claude.ai allow you to persist across chats?',
          options: [
            'Nothing, each chat is always isolated',
            'Custom instructions and uploaded knowledge files',
            'Your billing information only',
            'Only the chat color theme',
          ],
          correctIndex: 1,
          explanation: 'Projects store shared instructions and knowledge files used across every chat in that project.',
        },
        {
          id: 'm5q4',
          question: 'Why might Claude not know about very recent events by default?',
          options: [
            'It refuses to discuss the news',
            'Its training data has a knowledge cutoff date unless a tool like web search is enabled',
            'It is against Anthropic policy to ever discuss current events',
            'It only knows events older than 100 years',
          ],
          correctIndex: 1,
          explanation: 'Base model knowledge is frozen at a training cutoff; tools like web search extend this.',
        },
        {
          id: 'm5q5',
          question: 'What is the Model Context Protocol (MCP)?',
          options: [
            'A billing plan for the API',
            'An open standard for connecting Claude to external tools, data, and services',
            'A way to compress prompts',
            'A chat style preset',
          ],
          correctIndex: 1,
          explanation: 'MCP is an open standard enabling structured connections between Claude and external systems.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 6
  // ======================================================================
  {
    id: 'm6',
    title: 'Building with the Claude API',
    subtitle: 'From chat user to developer: the Messages API',
    icon: '💻',
    color: 'from-stone-500 to-amber-700',
    lessons: [
      {
        id: 'm6l1',
        title: 'API basics: the Messages endpoint',
        minutes: 8,
        blocks: [
          { type: 'paragraph', text: 'Developers integrate Claude through the Messages API. You send a list of messages (conversation turns) plus parameters, and get a generated response back.' },
          { type: 'code', language: 'bash', code: `curl https://api.anthropic.com/v1/messages \\
  -H "x-api-key: $ANTHROPIC_API_KEY" \\
  -H "anthropic-version: 2023-06-01" \\
  -H "content-type: application/json" \\
  -d '{
    "model": "claude-sonnet-4-5",
    "max_tokens": 1024,
    "system": "You are a concise technical writer.",
    "messages": [
      {"role": "user", "content": "Explain REST APIs in 3 sentences."}
    ]
  }'` },
          { type: 'list', items: [
            'model — which Claude model/version to use.',
            'max_tokens — the maximum length of the response.',
            'system — persistent instructions/persona for the whole conversation.',
            'messages — the array of user/assistant turns so far.',
          ] },
        ],
        keyTakeaways: [
          'The Messages API is the core way developers call Claude.',
          'Key parameters: model, max_tokens, system, messages.',
          'Every request can include the full conversation history.',
        ],
      },
      {
        id: 'm6l2',
        title: 'Key parameters: temperature, streaming & more',
        minutes: 7,
        blocks: [
          { type: 'list', items: [
            'temperature (0 to 1) — controls randomness. Lower = more focused/deterministic (good for factual/code tasks). Higher = more creative/varied (good for brainstorming).',
            'top_p / top_k — alternate ways to control output diversity, usually left at defaults.',
            'stream — if true, the response streams back token-by-token, great for responsive chat UIs.',
            'stop_sequences — custom strings that tell Claude to stop generating when reached.',
          ] },
          { type: 'tip', text: 'For deterministic tasks like data extraction or code generation, set temperature near 0. For brainstorming or creative writing, try 0.7-1.0.' },
        ],
        keyTakeaways: [
          'Temperature controls creativity vs. determinism.',
          'Streaming improves perceived responsiveness in apps.',
          'Stop sequences give fine control over where generation ends.',
        ],
      },
      {
        id: 'm6l3',
        title: 'Tool use (function calling)',
        minutes: 8,
        blocks: [
          { type: 'paragraph', text: 'Tool use lets Claude call functions you define — like checking a weather API, querying a database, or doing precise math — instead of guessing. You describe tools (name, description, input schema); Claude decides when to call one and returns a structured request; your code executes it and returns the result to Claude.' },
          { type: 'code', language: 'json', code: `{
  "name": "get_weather",
  "description": "Get the current weather for a city",
  "input_schema": {
    "type": "object",
    "properties": {
      "city": { "type": "string" }
    },
    "required": ["city"]
  }
}` },
          { type: 'list', items: [
            '1. You send Claude a prompt plus a list of available tools.',
            '2. If needed, Claude responds asking to call a specific tool with specific arguments.',
            '3. Your application runs that function and sends the result back to Claude.',
            '4. Claude uses the result to produce a final, grounded answer.',
          ] },
          { type: 'tip', text: 'Tool use is how you give Claude real-time data and real-world actions — it turns a text generator into an agent.' },
        ],
        keyTakeaways: [
          'Tool use lets Claude call developer-defined functions.',
          'Claude decides when a tool is needed and with what arguments.',
          'This grounds Claude in real data/actions instead of guesses.',
        ],
      },
      {
        id: 'm6l4',
        title: 'Vision, PDFs, and multimodal input via API',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'The API supports multimodal messages — you can include base64-encoded images or PDF documents as part of the "content" array alongside text, letting you build apps that analyze screenshots, scanned forms, or reports programmatically.' },
          { type: 'code', language: 'json', code: `{
  "role": "user",
  "content": [
    {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "..."}},
    {"type": "text", "text": "What does this chart show?"}
  ]
}` },
          { type: 'tip', text: 'Combine vision with tool use for powerful workflows, e.g., "read this invoice image, extract fields, then call a save_invoice tool."' },
        ],
        keyTakeaways: [
          'The API accepts multimodal content: text, images, and PDFs together.',
          'This enables automated document/image processing pipelines.',
          'Vision + tool use together unlock advanced automation.',
        ],
      },
    ],
    quiz: {
      id: 'm6q',
      title: 'Module 6 Check: Claude API',
      passPercent: 70,
      questions: [
        {
          id: 'm6q1',
          question: 'Which API parameter sets persistent instructions/persona for the whole conversation?',
          options: ['messages', 'system', 'max_tokens', 'stream'],
          correctIndex: 1,
          explanation: 'The system parameter sets overall behavior/persona for the conversation.',
        },
        {
          id: 'm6q2',
          question: 'For a task requiring precise, deterministic data extraction, what temperature setting is most appropriate?',
          options: ['Close to 0', 'Close to 1', 'Exactly 2', 'Temperature has no effect'],
          correctIndex: 0,
          explanation: 'Low temperature produces more focused, deterministic, less random output — ideal for extraction.',
        },
        {
          id: 'm6q3',
          question: 'What is the purpose of "tool use" (function calling)?',
          options: [
            'To make Claude\'s responses longer',
            'To let Claude call developer-defined functions for real data/actions instead of guessing',
            'To change the chat font',
            'To translate the API docs',
          ],
          correctIndex: 1,
          explanation: 'Tool use grounds Claude in real data by letting it call functions you define.',
        },
        {
          id: 'm6q4',
          question: 'In a tool-use flow, who actually executes the requested function?',
          options: [
            'Claude executes it directly on Anthropic\'s servers with no involvement from you',
            'Your own application code executes it and returns the result to Claude',
            'It is never executed, Claude just imagines the result',
            'The end user must manually run it in a terminal',
          ],
          correctIndex: 1,
          explanation: 'Claude requests a tool call; your application runs the actual function and returns the result.',
        },
        {
          id: 'm6q5',
          question: 'What does setting stream: true do in an API request?',
          options: [
            'Deletes the conversation after sending',
            'Returns the response token-by-token as it is generated',
            'Forces Claude to only output video',
            'Doubles the max_tokens limit',
          ],
          correctIndex: 1,
          explanation: 'Streaming returns partial output incrementally for more responsive UIs.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 7
  // ======================================================================
  {
    id: 'm7',
    title: 'Agents, Tools & Claude Code',
    subtitle: 'From single answers to autonomous, multi-step workflows',
    icon: '🤖',
    color: 'from-amber-600 to-yellow-700',
    lessons: [
      {
        id: 'm7l1',
        title: 'What makes an "agent"?',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'An AI agent is a system where the model doesn\'t just answer once — it plans, takes actions (via tools), observes results, and repeats in a loop until the task is done, with limited or no human intervention at each step.' },
          { type: 'list', items: [
            'Perceive: read the task and current state/context.',
            'Plan: decide the next action (or sequence of actions).',
            'Act: call a tool (search, code execution, database query, file edit).',
            'Observe: review the tool\'s result.',
            'Repeat until the goal is reached or a stopping condition is hit.',
          ] },
          { type: 'tip', text: 'Agents are most valuable for tasks with many small, verifiable steps — like coding, research, or data processing — where a human checking every single step would be slow.' },
        ],
        keyTakeaways: [
          'Agents loop through plan → act → observe cycles using tools.',
          'They reduce the need for step-by-step human micromanagement.',
          'Best suited to multi-step, verifiable tasks.',
        ],
      },
      {
        id: 'm7l2',
        title: 'Claude Code: agentic coding in your terminal',
        minutes: 8,
        blocks: [
          { type: 'paragraph', text: 'Claude Code is Anthropic\'s official command-line tool that lets Claude work directly inside your codebase: reading files, writing code, running tests, fixing bugs, and even committing changes, all guided by your natural-language instructions.' },
          { type: 'list', items: [
            'Install via npm and run `claude` inside a project directory.',
            'Ask it to "find and fix the bug causing test X to fail," and it will search the codebase, propose a fix, and can run the tests itself.',
            'Supports custom commands, hooks, and permission settings so you control what it\'s allowed to do automatically (e.g., auto-run safe commands, but ask before deleting files).',
            'Works well alongside human review — treat its commits/PRs like you would a junior engineer\'s: review before merging into production.',
          ] },
          { type: 'warning', text: 'Always sandbox or use version control (git) when letting an agent make changes to code, so you can review and revert if needed.' },
        ],
        keyTakeaways: [
          'Claude Code brings agentic capabilities to real codebases via the terminal.',
          'It can read, write, run, and test code autonomously.',
          'Use permissions and git to stay safely in control.',
        ],
      },
      {
        id: 'm7l3',
        title: 'Retrieval-Augmented Generation (RAG) basics',
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'RAG is a pattern for giving Claude access to large or private knowledge bases that don\'t fit in a prompt: relevant chunks of documents are retrieved (often via vector search) and inserted into the prompt before Claude answers.' },
          { type: 'list', items: [
            '1. Split your documents into chunks and store them with embeddings in a vector database.',
            '2. When a user asks a question, find the most relevant chunks.',
            '3. Insert those chunks into the prompt as context.',
            '4. Ask Claude to answer using only that retrieved context.',
          ] },
          { type: 'tip', text: 'RAG combines the strengths of search (fresh, specific, private data) with the strengths of an LLM (fluent reasoning and synthesis).' },
        ],
        keyTakeaways: [
          'RAG retrieves relevant external context before Claude answers.',
          'It lets Claude work accurately with knowledge bases too large to fit in a prompt.',
          'Grounding answers in retrieved text reduces hallucination.',
        ],
      },
      {
        id: 'm7l4',
        title: 'Designing safe, reliable agentic workflows',
        minutes: 6,
        blocks: [
          { type: 'list', items: [
            'Start narrow: automate one well-defined sub-task before trying to automate an entire workflow end-to-end.',
            'Add guardrails: require human approval for irreversible actions (sending emails, deleting data, spending money).',
            'Log everything: keep a record of every tool call and decision for debugging and auditing.',
            'Set limits: cap the number of steps/iterations to avoid runaway loops or costs.',
            'Test with adversarial/edge-case inputs before trusting an agent in production.',
          ] },
          { type: 'warning', title: 'Golden rule', text: 'The more autonomy and real-world power you give an agent, the more review, logging, and guardrails it needs.' },
        ],
        keyTakeaways: [
          'Start with narrow, well-scoped automations.',
          'Add human-in-the-loop approval for risky/irreversible actions.',
          'Logging and step limits keep agentic systems safe and debuggable.',
        ],
      },
    ],
    quiz: {
      id: 'm7q',
      title: 'Module 7 Check: Agents, Tools & Claude Code',
      passPercent: 70,
      questions: [
        {
          id: 'm7q1',
          question: 'What fundamentally distinguishes an "agent" from a single prompt-response interaction?',
          options: [
            'Agents are always faster',
            'Agents loop through planning, acting via tools, and observing results across multiple steps',
            'Agents only work with images',
            'Agents require no instructions at all',
          ],
          correctIndex: 1,
          explanation: 'Agents operate in an iterative loop of plan-act-observe rather than a single response.',
        },
        {
          id: 'm7q2',
          question: 'What is Claude Code?',
          options: [
            'A programming language created by Anthropic',
            'A command-line agentic tool that lets Claude read, write, and run code in your project',
            'A certification exam',
            'A web design theme',
          ],
          correctIndex: 1,
          explanation: 'Claude Code is Anthropic\'s terminal-based agentic coding tool.',
        },
        {
          id: 'm7q3',
          question: 'In a RAG pipeline, what happens before Claude generates its final answer?',
          options: [
            'Nothing, RAG is identical to a normal prompt',
            'Relevant document chunks are retrieved and inserted into the prompt as context',
            'The entire internet is downloaded',
            'Claude is retrained from scratch',
          ],
          correctIndex: 1,
          explanation: 'RAG retrieves relevant chunks (often via vector search) and adds them as context before generation.',
        },
        {
          id: 'm7q4',
          question: 'What is a recommended safety practice when letting Claude Code modify a real codebase?',
          options: [
            'Disable version control to move faster',
            'Use git and review changes before merging to production',
            'Give it unrestricted production database access immediately',
            'Never look at what it changed',
          ],
          correctIndex: 1,
          explanation: 'Version control and human review provide safety nets for agentic code changes.',
        },
        {
          id: 'm7q5',
          question: 'Which practice helps keep agentic workflows safe?',
          options: [
            'Removing all step limits so it can run indefinitely',
            'Requiring human approval for irreversible, high-impact actions',
            'Avoiding any logging to keep things simple',
            'Giving the agent maximum autonomy from day one',
          ],
          correctIndex: 1,
          explanation: 'Human-in-the-loop approval for risky actions is a core safety guardrail for agents.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 8
  // ======================================================================
  {
    id: 'm8',
    title: 'Safety, Ethics & Responsible Use',
    subtitle: "Understanding Claude's guardrails, limits, and your responsibilities",
    icon: '🛡️',
    color: 'from-emerald-500 to-amber-500',
    lessons: [
      {
        id: 'm8l1',
        title: "Anthropic's approach to AI safety",
        minutes: 7,
        blocks: [
          { type: 'paragraph', text: 'Anthropic was founded specifically around AI safety research. Core ideas that shape Claude\'s behavior:' },
          { type: 'list', items: [
            'Constitutional AI — Claude is trained to critique and revise its own responses against a written set of principles (drawing on sources like the UN Declaration of Human Rights and trust & safety best practices), reducing reliance on large-scale human labeling of harmful content.',
            'Helpful, Harmless, Honest (HHH) — the north-star framework balancing usefulness against avoiding harm and being truthful.',
            'Red-teaming — Anthropic and external researchers actively try to break Claude\'s safeguards to find and fix weaknesses before release.',
            'Usage policies — rules about what Claude should not help with (e.g., creating weapons, malware, or child safety violations), enforced through both training and platform-level monitoring.',
          ] },
        ],
        keyTakeaways: [
          'Constitutional AI shapes Claude\'s behavior using a written set of principles.',
          'The Helpful-Harmless-Honest framework guides tradeoffs.',
          'Red-teaming and usage policies add additional layers of safety.',
        ],
      },
      {
        id: 'm8l2',
        title: 'Known limitations',
        minutes: 7,
        blocks: [
          { type: 'list', items: [
            'Hallucination — Claude can confidently state incorrect facts, fake citations, or invent details, especially on obscure topics or precise numbers.',
            'Knowledge cutoff — without tools like web search, Claude does not know about events after its training data ends.',
            'Math/precision errors — large numeric calculations can be wrong; Claude benefits from being asked to show its work or use a code tool to compute precisely.',
            'Context limits — even with large context windows, extremely long inputs can lead to details being underweighted; summarizing/chunking can help.',
            'No real "memory" by default — a new chat generally doesn\'t know what happened in a previous unrelated chat unless you provide it or use memory features explicitly.',
          ] },
          { type: 'tip', text: 'Treat Claude as a very capable assistant, not an infallible oracle. Combine its speed with your judgment and domain expertise.' },
        ],
        keyTakeaways: [
          'Claude can hallucinate facts, citations, and numbers.',
          'It has a training knowledge cutoff unless given live tools.',
          'Human judgment and verification remain essential.',
        ],
      },
      {
        id: 'm8l3',
        title: 'Privacy & data use',
        minutes: 6,
        blocks: [
          { type: 'list', items: [
            'Avoid pasting sensitive personal data (SSNs, passwords, medical records) into chats unless you understand your organization\'s data policy and Anthropic\'s terms.',
            'For businesses, API usage and consumer product usage typically have different data retention/training policies — always check current terms before sending sensitive data.',
            'Be mindful when uploading documents that may contain confidential information about third parties (e.g., client data) — ensure you have the right to share it.',
            'Use enterprise offerings (e.g., Claude for Work/Enterprise, cloud platform deployments) when stronger data governance is required.',
          ] },
          { type: 'warning', text: 'Policies change over time — always check Anthropic\'s current privacy policy and your organization\'s AI usage guidelines before sharing sensitive data.' },
        ],
        keyTakeaways: [
          'Be cautious about sharing sensitive personal or confidential data.',
          'Consumer and enterprise/API products may have different data policies.',
          'Always check current terms before high-stakes data sharing.',
        ],
      },
      {
        id: 'm8l4',
        title: 'Using AI responsibly',
        minutes: 6,
        blocks: [
          { type: 'list', items: [
            'Disclose AI assistance where relevant (school, work, publishing) according to your institution\'s policies.',
            'Don\'t outsource judgment entirely — use Claude to inform decisions, not replace accountability for them.',
            'Watch for overreliance — keep practicing core skills yourself so you can evaluate AI output critically.',
            'Consider bias — like all models trained on human-generated text, Claude can reflect biases present in training data; review outputs critically, especially for sensitive decisions (hiring, lending, etc.).',
            'Respect intellectual property and copyright when generating or reusing content.',
          ] },
        ],
        keyTakeaways: [
          'Responsible use includes disclosure, critical review, and accountability.',
          'Avoid overreliance — keep your own skills sharp.',
          'Be aware of and check for potential bias in sensitive use cases.',
        ],
      },
    ],
    quiz: {
      id: 'm8q',
      title: 'Module 8 Check: Safety & Ethics',
      passPercent: 70,
      questions: [
        {
          id: 'm8q1',
          question: 'What does the "HHH" framework stand for in Anthropic\'s approach to Claude?',
          options: [
            'High, Heavy, Hard',
            'Helpful, Harmless, Honest',
            'Hosted, Hybrid, Human',
            'Heuristic, Hierarchical, Holistic',
          ],
          correctIndex: 1,
          explanation: 'Helpful, Harmless, Honest is the guiding framework for balancing usefulness and safety.',
        },
        {
          id: 'm8q2',
          question: 'What is a known limitation of Claude (and LLMs generally)?',
          options: [
            'They never make mistakes',
            'They can hallucinate confident but false information',
            'They can only answer yes/no questions',
            'They cannot process any text longer than one sentence',
          ],
          correctIndex: 1,
          explanation: 'Hallucination — confidently stating false information — is a known risk with all LLMs.',
        },
        {
          id: 'm8q3',
          question: 'What should you be cautious about before pasting data into a Claude chat?',
          options: [
            'Nothing, all data is completely safe to share everywhere',
            'Sensitive personal or confidential third-party data, given data policies',
            'The color of your text',
            'Whether Claude likes the topic',
          ],
          correctIndex: 1,
          explanation: 'You should be mindful about sharing sensitive or confidential data and check applicable data policies.',
        },
        {
          id: 'm8q4',
          question: 'What is "red-teaming" in the context of AI safety?',
          options: [
            'A marketing campaign',
            'Deliberately trying to break a model\'s safeguards to find and fix weaknesses before release',
            'A type of model architecture',
            'A customer support ticketing system',
          ],
          correctIndex: 1,
          explanation: 'Red-teaming involves adversarial testing to find safety weaknesses before deployment.',
        },
        {
          id: 'm8q5',
          question: 'Why is "overreliance" on AI a concern worth managing?',
          options: [
            'Because AI is always wrong',
            'Because it can erode your own critical thinking/skills and judgment over time if used uncritically',
            'Because it is illegal everywhere',
            'It is not a real concern at all',
          ],
          correctIndex: 1,
          explanation: 'Overreliance can weaken independent judgment and critical evaluation skills if not managed deliberately.',
        },
      ],
    },
  },

  // ======================================================================
  // MODULE 9
  // ======================================================================
  {
    id: 'm9',
    title: 'Real-World Mastery',
    subtitle: 'Professional workflows, use cases, and becoming a power user',
    icon: '🏆',
    color: 'from-orange-500 to-amber-600',
    lessons: [
      {
        id: 'm9l1',
        title: 'Claude across professions',
        minutes: 7,
        blocks: [
          { type: 'list', items: [
            'Writers & marketers: drafting, editing, repurposing content across formats, brainstorming headlines, A/B copy variants.',
            'Developers: code generation, debugging, code review, writing tests, documentation, learning new frameworks via Claude Code.',
            'Researchers & analysts: summarizing papers/reports, extracting structured data from PDFs, comparing sources.',
            'Educators & students: generating practice questions, explaining concepts at different levels, lesson planning, essay feedback.',
            'Customer support & operations: drafting responses, summarizing tickets, building support bots with tool use.',
            'Legal & finance (with human oversight): first-pass contract review notes, summarizing filings, explaining clauses in plain language.',
          ] },
          { type: 'tip', text: 'The highest-leverage use cases are usually repetitive, well-defined tasks performed often — automate those first.' },
        ],
        keyTakeaways: [
          'Claude adds value across nearly every knowledge-work profession.',
          'High-frequency, well-defined tasks are the best automation candidates.',
          'Human oversight remains essential in regulated or high-stakes domains.',
        ],
      },
      {
        id: 'm9l2',
        title: 'Building a personal prompt library',
        minutes: 6,
        blocks: [
          { type: 'paragraph', text: 'Professionals who get the most value from Claude maintain a reusable library of prompt templates instead of reinventing prompts every time.' },
          { type: 'list', items: [
            'Keep a doc/Project with your best prompts organized by task (emails, reports, code reviews, etc.).',
            'Include placeholders like [TOPIC] or [AUDIENCE] you can swap in quickly.',
            'Note what worked and what didn\'t for future reference.',
            'Version your system prompts for recurring Projects as your needs evolve.',
          ] },
        ],
        keyTakeaways: [
          'A personal prompt library saves time on recurring tasks.',
          'Use placeholders to make templates reusable.',
          'Treat your best prompts as living documents to refine over time.',
        ],
      },
      {
        id: 'm9l3',
        title: 'Common mistakes beginners make',
        minutes: 6,
        blocks: [
          { type: 'list', items: [
            'Being too vague, then blaming the model for a generic answer.',
            'Not providing source material and expecting perfectly accurate facts/citations.',
            'Writing one giant prompt for a huge multi-part task instead of chaining smaller steps.',
            'Never iterating — accepting the first draft instead of refining with feedback.',
            'Forgetting to double check important numbers, quotes, or legal/medical claims.',
            'Not using Projects/system prompts, so repeating the same context over and over.',
          ] },
          { type: 'tip', text: 'Most "Claude isn\'t smart enough" complaints are actually prompting issues — revisit Modules 3-4 whenever you feel stuck.' },
        ],
        keyTakeaways: [
          'Most quality issues trace back to vague prompts or missing context.',
          'Iteration and verification are non-negotiable professional habits.',
          'Reusing context (Projects, templates) avoids wasted effort.',
        ],
      },
      {
        id: 'm9l4',
        title: 'Staying current & continuing your journey',
        minutes: 5,
        blocks: [
          { type: 'list', items: [
            'Anthropic regularly ships new models and features — check release notes/changelogs periodically.',
            'Follow Anthropic\'s official documentation (docs.anthropic.com) for the latest best practices on prompting and the API.',
            'Experiment deliberately: pick one new feature a month (e.g., extended thinking, MCP, a new Artifact type) and build something small with it.',
            'Join communities (developer forums, Discord/Slack groups) to see how others solve real problems with Claude.',
          ] },
          { type: 'quote', text: 'Mastery of Claude isn\'t memorizing one perfect prompt — it\'s building the judgment to know what to ask for, how to phrase it, and when to double-check the answer.' },
        ],
        keyTakeaways: [
          'The field moves quickly — build a habit of continuous learning.',
          'Official docs are the best source of up-to-date best practices.',
          'Deliberate, small experiments build lasting expertise.',
        ],
      },
    ],
    quiz: {
      id: 'm9q',
      title: 'Module 9 Check: Real-World Mastery',
      passPercent: 70,
      questions: [
        {
          id: 'm9q1',
          question: 'What kind of tasks are the best first candidates for automating with Claude?',
          options: [
            'Rare, one-off tasks you do once a year',
            'Repetitive, well-defined tasks performed often',
            'Tasks with no clear definition of success',
            'Tasks that are impossible to describe in words',
          ],
          correctIndex: 1,
          explanation: 'High-frequency, well-defined tasks give the best return on investment for prompt templates/automation.',
        },
        {
          id: 'm9q2',
          question: 'What is the benefit of maintaining a personal prompt library?',
          options: [
            'It slows you down unnecessarily',
            'It saves time and improves consistency on recurring tasks',
            'It is required by Anthropic\'s terms of service',
            'It replaces the need to ever write a new prompt',
          ],
          correctIndex: 1,
          explanation: 'Reusable, refined prompt templates save time and increase consistency.',
        },
        {
          id: 'm9q3',
          question: 'A common beginner mistake is:',
          options: [
            'Iterating on prompts with specific feedback',
            'Giving Claude a vague prompt and blaming the model for a generic answer',
            'Using Projects to store recurring context',
            'Verifying important facts independently',
          ],
          correctIndex: 1,
          explanation: 'Vague prompts are one of the most common causes of disappointing results.',
        },
        {
          id: 'm9q4',
          question: 'Where should you look for the most up-to-date best practices on prompting and the API?',
          options: [
            'Random social media posts only',
            'Anthropic\'s official documentation',
            'Guessing based on older AI tools',
            'You never need to check, nothing ever changes',
          ],
          correctIndex: 1,
          explanation: 'Official documentation is the most reliable source for current best practices and features.',
        },
        {
          id: 'm9q5',
          question: 'What is the course\'s overall definition of "mastery" of Claude?',
          options: [
            'Memorizing one single perfect prompt forever',
            'Building judgment for what to ask, how to phrase it, and when to verify answers',
            'Never using Claude for anything important',
            'Avoiding all advanced features',
          ],
          correctIndex: 1,
          explanation: 'True mastery is adaptable judgment, not a single memorized trick.',
        },
      ],
    },
  },
];

export const totalLessons = modules.reduce((acc, m) => acc + m.lessons.length, 0);
