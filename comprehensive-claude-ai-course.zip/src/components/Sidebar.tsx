import { modules } from '../data/modules';
import type { ProgressState } from '../types';
import { CheckCircle2, Circle, FlaskConical, GraduationCap, Menu, X, Award } from 'lucide-react';
import { useState } from 'react';

export type Selection =
  | { kind: 'landing' }
  | { kind: 'lesson'; moduleId: string; lessonId: string }
  | { kind: 'quiz'; moduleId: string }
  | { kind: 'lab' }
  | { kind: 'final' }
  | { kind: 'certificate' };

interface Props {
  selection: Selection;
  onSelect: (s: Selection) => void;
  progress: ProgressState;
}

function isModuleComplete(progress: ProgressState, moduleId: string) {
  const mod = modules.find((m) => m.id === moduleId)!;
  const lessonsDone = mod.lessons.every((l) => progress.completedLessons[l.id]);
  const quizDone = progress.quizPassed[mod.quiz.id];
  return lessonsDone && quizDone;
}

export default function Sidebar({ selection, onSelect, progress }: Props) {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ m1: true });

  const allModulesDone = modules.every((m) => isModuleComplete(progress, m.id));

  const content = (
    <div className="flex h-full flex-col bg-stone-900 text-stone-200">
      <div className="p-5 border-b border-stone-700/60">
        <button onClick={() => onSelect({ kind: 'landing' })} className="flex items-center gap-2 text-left w-full">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-orange-400 to-amber-600 flex items-center justify-center font-bold text-stone-900 text-lg shrink-0">
            C
          </div>
          <div>
            <p className="font-bold text-white leading-tight">Claude AI Mastery</p>
            <p className="text-xs text-stone-400">Newbie → Professional</p>
          </div>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
        {modules.map((mod, idx) => {
          const isExpanded = !!expanded[mod.id];
          const moduleDone = isModuleComplete(progress, mod.id);
          return (
            <div key={mod.id} className="rounded-xl overflow-hidden">
              <button
                onClick={() => setExpanded((e) => ({ ...e, [mod.id]: !isExpanded }))}
                className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-stone-800 transition rounded-xl"
              >
                <span className="text-lg">{mod.icon}</span>
                <div className="flex-1 text-left min-w-0">
                  <p className="text-sm font-semibold text-stone-100 truncate">
                    {idx + 1}. {mod.title}
                  </p>
                </div>
                {moduleDone ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                ) : (
                  <Circle className="h-4 w-4 text-stone-600 shrink-0" />
                )}
              </button>
              {isExpanded && (
                <div className="pl-4 pr-1 pb-2 space-y-0.5">
                  {mod.lessons.map((lesson) => {
                    const done = !!progress.completedLessons[lesson.id];
                    const active =
                      selection.kind === 'lesson' && selection.moduleId === mod.id && selection.lessonId === lesson.id;
                    return (
                      <button
                        key={lesson.id}
                        onClick={() => {
                          onSelect({ kind: 'lesson', moduleId: mod.id, lessonId: lesson.id });
                          setOpen(false);
                        }}
                        className={`w-full flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-left transition ${
                          active ? 'bg-orange-500/20 text-orange-200' : 'text-stone-400 hover:bg-stone-800 hover:text-stone-200'
                        }`}
                      >
                        {done ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                        ) : (
                          <Circle className="h-3.5 w-3.5 text-stone-600 shrink-0" />
                        )}
                        <span className="truncate">{lesson.title}</span>
                      </button>
                    );
                  })}
                  <button
                    onClick={() => {
                      onSelect({ kind: 'quiz', moduleId: mod.id });
                      setOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-left transition ${
                      selection.kind === 'quiz' && selection.moduleId === mod.id
                        ? 'bg-orange-500/20 text-orange-200'
                        : 'text-stone-400 hover:bg-stone-800 hover:text-stone-200'
                    }`}
                  >
                    {progress.quizPassed[mod.quiz.id] ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <GraduationCap className="h-3.5 w-3.5 text-stone-500 shrink-0" />
                    )}
                    <span className="truncate font-medium">Module Quiz</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}

        <div className="pt-3 mt-3 border-t border-stone-700/60 space-y-1">
          <button
            onClick={() => {
              onSelect({ kind: 'lab' });
              setOpen(false);
            }}
            className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl transition ${
              selection.kind === 'lab' ? 'bg-orange-500/20 text-orange-200' : 'hover:bg-stone-800 text-stone-200'
            }`}
          >
            <FlaskConical className="h-4 w-4 text-amber-400 shrink-0" />
            <span className="text-sm font-semibold">Prompt Lab</span>
          </button>
          <button
            onClick={() => {
              onSelect({ kind: 'final' });
              setOpen(false);
            }}
            className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl transition ${
              selection.kind === 'final' ? 'bg-orange-500/20 text-orange-200' : 'hover:bg-stone-800 text-stone-200'
            }`}
          >
            <GraduationCap className="h-4 w-4 text-amber-400 shrink-0" />
            <span className="text-sm font-semibold">Final Exam</span>
          </button>
          <button
            onClick={() => {
              onSelect({ kind: 'certificate' });
              setOpen(false);
            }}
            disabled={!allModulesDone}
            className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl transition disabled:opacity-40 disabled:cursor-not-allowed ${
              selection.kind === 'certificate' ? 'bg-orange-500/20 text-orange-200' : 'hover:bg-stone-800 text-stone-200'
            }`}
          >
            <Award className="h-4 w-4 text-amber-400 shrink-0" />
            <span className="text-sm font-semibold">Certificate</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <div className="lg:hidden flex items-center justify-between bg-stone-900 text-white px-4 py-3">
        <button onClick={() => onSelect({ kind: 'landing' })} className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-orange-400 to-amber-600 flex items-center justify-center font-bold text-stone-900">
            C
          </div>
          <span className="font-bold">Claude AI Mastery</span>
        </button>
        <button onClick={() => setOpen(true)} aria-label="Open menu">
          <Menu className="h-6 w-6" />
        </button>
      </div>

      <aside className="hidden lg:block w-80 shrink-0 h-screen sticky top-0">{content}</aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw]">
            <div className="relative h-full">
              <button
                onClick={() => setOpen(false)}
                className="absolute right-3 top-3 z-10 text-stone-300 hover:text-white"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
              {content}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
