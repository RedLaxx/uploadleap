import { useMemo, useState } from 'react';
import type { Quiz } from '../types';
import { CheckCircle2, XCircle, RotateCcw, Award, ArrowRight } from 'lucide-react';

interface Props {
  quiz: Quiz;
  onComplete: (percent: number, passed: boolean) => void;
  accent?: string;
  onContinue?: () => void;
  continueLabel?: string;
}

export default function QuizView({ quiz, onComplete, accent = 'orange', onContinue, continueLabel }: Props) {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [attempt, setAttempt] = useState(0);

  const allAnswered = quiz.questions.every((q) => answers[q.id] !== undefined);

  const { correctCount, percent, passed } = useMemo(() => {
    if (!submitted) return { correctCount: 0, percent: 0, passed: false };
    const correct = quiz.questions.filter((q) => answers[q.id] === q.correctIndex).length;
    const pct = Math.round((correct / quiz.questions.length) * 100);
    return { correctCount: correct, percent: pct, passed: pct >= quiz.passPercent };
  }, [submitted, answers, quiz]);

  const handleSubmit = () => {
    setSubmitted(true);
    const correct = quiz.questions.filter((q) => answers[q.id] === q.correctIndex).length;
    const pct = Math.round((correct / quiz.questions.length) * 100);
    onComplete(pct, pct >= quiz.passPercent);
  };

  const handleRetry = () => {
    setAnswers({});
    setSubmitted(false);
    setAttempt((a) => a + 1);
  };

  return (
    <div className="space-y-6" key={attempt}>
      <div className="rounded-2xl border border-stone-200 bg-white p-5 sm:p-6">
        <div className="flex items-center gap-2 mb-1">
          <Award className={`h-5 w-5 text-${accent}-500`} />
          <h2 className="text-lg font-bold text-stone-800">{quiz.title}</h2>
        </div>
        <p className="text-sm text-stone-500">
          {quiz.questions.length} questions · Pass mark: {quiz.passPercent}%
        </p>
      </div>

      {submitted && (
        <div
          className={`rounded-2xl p-5 sm:p-6 border ${
            passed ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {passed ? (
              <CheckCircle2 className="h-8 w-8 text-emerald-500 shrink-0" />
            ) : (
              <XCircle className="h-8 w-8 text-rose-500 shrink-0" />
            )}
            <div>
              <p className={`font-bold text-lg ${passed ? 'text-emerald-800' : 'text-rose-800'}`}>
                {passed ? 'Nice work — you passed!' : 'Not quite — try again'}
              </p>
              <p className={`text-sm ${passed ? 'text-emerald-700' : 'text-rose-700'}`}>
                You scored {correctCount}/{quiz.questions.length} ({percent}%). Needed {quiz.passPercent}% to pass.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 mt-4">
            {!passed && (
              <button
                onClick={handleRetry}
                className="inline-flex items-center gap-2 rounded-lg bg-stone-800 text-white px-4 py-2 text-sm font-semibold hover:bg-stone-700 transition"
              >
                <RotateCcw className="h-4 w-4" /> Retry quiz
              </button>
            )}
            {passed && onContinue && (
              <button
                onClick={onContinue}
                className="inline-flex items-center gap-2 rounded-lg bg-orange-500 text-white px-4 py-2 text-sm font-semibold hover:bg-orange-600 transition"
              >
                {continueLabel || 'Continue'} <ArrowRight className="h-4 w-4" />
              </button>
            )}
            {!passed && (
              <span className="text-xs text-stone-500 self-center">Review the explanations below, then retry.</span>
            )}
          </div>
        </div>
      )}

      <div className="space-y-5">
        {quiz.questions.map((q, qi) => {
          const userAnswer = answers[q.id];
          return (
            <div key={q.id} className="rounded-2xl border border-stone-200 bg-white p-5">
              <p className="font-semibold text-stone-800 mb-3">
                {qi + 1}. {q.question}
              </p>
              <div className="space-y-2">
                {q.options.map((opt, oi) => {
                  const isSelected = userAnswer === oi;
                  const isCorrect = q.correctIndex === oi;
                  let style = 'border-stone-200 hover:border-orange-300 hover:bg-orange-50/50';
                  if (submitted) {
                    if (isCorrect) style = 'border-emerald-400 bg-emerald-50';
                    else if (isSelected && !isCorrect) style = 'border-rose-400 bg-rose-50';
                    else style = 'border-stone-200 opacity-60';
                  } else if (isSelected) {
                    style = 'border-orange-400 bg-orange-50';
                  }
                  return (
                    <button
                      key={oi}
                      disabled={submitted}
                      onClick={() => setAnswers((a) => ({ ...a, [q.id]: oi }))}
                      className={`w-full text-left rounded-xl border px-4 py-2.5 text-sm transition flex items-center justify-between gap-2 ${style} ${
                        submitted ? 'cursor-default' : 'cursor-pointer'
                      }`}
                    >
                      <span className="text-stone-700">{opt}</span>
                      {submitted && isCorrect && <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />}
                      {submitted && isSelected && !isCorrect && <XCircle className="h-4 w-4 text-rose-500 shrink-0" />}
                    </button>
                  );
                })}
              </div>
              {submitted && (
                <p className="mt-3 text-xs rounded-lg bg-stone-50 border border-stone-200 p-3 text-stone-600 leading-relaxed">
                  <span className="font-semibold text-stone-700">Why: </span>
                  {q.explanation}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {!submitted && (
        <button
          onClick={handleSubmit}
          disabled={!allAnswered}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-orange-500 text-white px-6 py-3 font-semibold hover:bg-orange-600 transition disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Submit answers
        </button>
      )}
    </div>
  );
}
