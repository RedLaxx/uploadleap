import { modules, totalLessons } from '../data/modules';
import type { ProgressState } from '../types';

export default function TopProgress({ progress }: { progress: ProgressState }) {
  const completedLessons = Object.keys(progress.completedLessons).filter((id) => progress.completedLessons[id]).length;
  const passedQuizzes = modules.filter((m) => progress.quizPassed[m.quiz.id]).length;
  const totalUnits = totalLessons + modules.length + 1; // + final exam
  const doneUnits = completedLessons + passedQuizzes + (progress.finalExamPassed ? 1 : 0);
  const pct = Math.round((doneUnits / totalUnits) * 100);

  return (
    <div className="flex items-center gap-3 w-full">
      <div className="flex-1 h-2 rounded-full bg-stone-200 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-orange-400 to-amber-500 transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-xs font-semibold text-stone-500 whitespace-nowrap">{pct}% complete</span>
    </div>
  );
}
