import { Award, Printer, Lock } from 'lucide-react';
import type { ProgressState } from '../types';
import { modules } from '../data/modules';

interface Props {
  progress: ProgressState;
  allModulesDone: boolean;
  onNameChange: (name: string) => void;
}

export default function Certificate({ progress, allModulesDone, onNameChange }: Props) {
  const ready = allModulesDone && progress.finalExamPassed && progress.studentName.trim().length > 0;
  const today = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });

  if (!ready) {
    const missing: string[] = [];
    if (!progress.studentName.trim()) missing.push('Enter your name');
    if (!allModulesDone) missing.push('Complete all 9 modules + their quizzes');
    if (!progress.finalExamPassed) missing.push('Pass the Final Exam (80%+)');

    return (
      <div className="max-w-2xl mx-auto px-6 py-16 text-center">
        <div className="mx-auto mb-5 h-16 w-16 rounded-2xl bg-stone-100 flex items-center justify-center">
          <Lock className="h-8 w-8 text-stone-400" />
        </div>
        <h1 className="text-2xl font-extrabold text-stone-900 mb-2">Certificate locked</h1>
        <p className="text-stone-500 mb-6">Finish these steps to unlock your certificate of completion:</p>
        <ul className="inline-flex flex-col gap-2 text-left mb-6">
          {missing.map((m) => (
            <li key={m} className="flex items-center gap-2 text-stone-700 text-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-orange-400" /> {m}
            </li>
          ))}
        </ul>
        {!progress.studentName.trim() && (
          <div className="max-w-xs mx-auto">
            <input
              onChange={(e) => onNameChange(e.target.value)}
              placeholder="Enter your name"
              className="w-full rounded-xl border border-stone-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>
        )}
        <p className="text-xs text-stone-400 mt-8">
          Modules completed: {modules.filter((m) => m.lessons.every((l) => progress.completedLessons[l.id]) && progress.quizPassed[m.quiz.id]).length} / {modules.length}
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-14">
      <div className="text-center mb-6 print:hidden">
        <h1 className="text-2xl font-extrabold text-stone-900 mb-2">🎉 Congratulations!</h1>
        <p className="text-stone-500">You've completed the Claude AI Mastery course. Here is your certificate.</p>
      </div>

      <div className="relative rounded-[2rem] border-8 border-double border-amber-300 bg-gradient-to-br from-amber-50 via-white to-orange-50 p-10 sm:p-14 text-center shadow-xl">
        <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-gradient-to-br from-orange-400 to-amber-600 flex items-center justify-center">
          <Award className="h-8 w-8 text-white" />
        </div>
        <p className="text-xs tracking-[0.3em] font-bold text-amber-600 mb-3">CERTIFICATE OF COMPLETION</p>
        <p className="text-stone-500 mb-2">This certifies that</p>
        <p className="text-3xl sm:text-4xl font-extrabold text-stone-900 mb-3 font-serif">{progress.studentName}</p>
        <p className="text-stone-500 mb-6 max-w-md mx-auto leading-relaxed">
          has successfully completed the <span className="font-semibold text-stone-700">Claude AI Mastery</span> course
          — progressing from absolute beginner to professional Claude AI user, passing all {modules.length} module
          quizzes and the final certification exam with a score of{' '}
          <span className="font-semibold text-stone-700">{progress.finalExamScore}%</span>.
        </p>
        <div className="flex items-center justify-center gap-10 text-sm text-stone-500 mb-2">
          <div>
            <p className="font-serif text-lg text-stone-800 italic">Anthropic Claude Academy</p>
            <p className="text-xs">Issuing body</p>
          </div>
          <div>
            <p className="font-serif text-lg text-stone-800">{today}</p>
            <p className="text-xs">Date</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-6 print:hidden">
        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-xl bg-stone-900 text-white px-5 py-2.5 text-sm font-semibold hover:bg-stone-800 transition"
        >
          <Printer className="h-4 w-4" /> Print / Save as PDF
        </button>
      </div>
    </div>
  );
}
