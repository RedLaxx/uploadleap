import { modules, totalLessons } from '../data/modules';
import { ArrowRight, Sparkles, BookOpen, FlaskConical, Award, Clock } from 'lucide-react';

interface Props {
  studentName: string;
  onNameChange: (name: string) => void;
  onStart: () => void;
}

export default function Landing({ studentName, onNameChange, onStart }: Props) {
  const totalMinutes = modules.reduce((acc, m) => acc + m.lessons.reduce((a, l) => a + l.minutes, 0), 0);

  return (
    <div className="min-h-full">
      <section className="relative overflow-hidden bg-gradient-to-br from-stone-900 via-stone-900 to-orange-950 text-white">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_20%_20%,theme(colors.orange.400),transparent_45%),radial-gradient(circle_at_80%_0%,theme(colors.amber.500),transparent_40%)]" />
        <div className="relative max-w-5xl mx-auto px-6 py-16 sm:py-24">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold text-amber-200 mb-6">
            <Sparkles className="h-3.5 w-3.5" /> Interactive course · Quizzes · Certificate
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight mb-4">
            Claude AI Mastery:<br className="hidden sm:block" /> From Absolute Beginner to Professional
          </h1>
          <p className="text-stone-300 text-lg max-w-2xl mb-8 leading-relaxed">
            A complete, hands-on course covering everything about Claude — Anthropic's AI assistant. Learn core
            concepts, master prompt engineering, build with the API and agents, and finish with a graded certification
            exam.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 max-w-md">
            <input
              value={studentName}
              onChange={(e) => onNameChange(e.target.value)}
              placeholder="Enter your name"
              className="flex-1 rounded-xl bg-white/10 border border-white/20 px-4 py-3 text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
            <button
              onClick={onStart}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-orange-500 px-6 py-3 font-semibold hover:bg-orange-400 transition text-stone-900 whitespace-nowrap"
            >
              Start learning <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          <div className="flex flex-wrap gap-6 mt-10 text-sm text-stone-300">
            <div className="flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-amber-400" /> {modules.length} modules · {totalLessons} lessons
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-400" /> ~{Math.round(totalMinutes / 60)} hours of content
            </div>
            <div className="flex items-center gap-2">
              <FlaskConical className="h-4 w-4 text-amber-400" /> Interactive Prompt Lab
            </div>
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-400" /> Graded quizzes + final certificate
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-14">
        <h2 className="text-2xl font-bold text-stone-800 mb-2">Course roadmap</h2>
        <p className="text-stone-500 mb-8">
          Nine modules take you step by step from "what is Claude?" to building agentic, production-grade workflows.
        </p>
        <div className="grid sm:grid-cols-2 gap-4">
          {modules.map((mod, i) => (
            <div key={mod.id} className="rounded-2xl border border-stone-200 bg-white p-5 flex gap-4 hover:shadow-md transition">
              <div
                className={`h-11 w-11 shrink-0 rounded-xl bg-gradient-to-br ${mod.color} flex items-center justify-center text-xl`}
              >
                {mod.icon}
              </div>
              <div>
                <p className="text-xs font-semibold text-orange-500 mb-0.5">MODULE {i + 1}</p>
                <p className="font-bold text-stone-800 leading-tight mb-1">{mod.title}</p>
                <p className="text-sm text-stone-500">{mod.subtitle}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-2xl border border-orange-200 bg-orange-50 p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
          <div>
            <p className="font-bold text-stone-800 mb-1">Ready to become a Claude power user?</p>
            <p className="text-sm text-stone-600">Your progress saves automatically in this browser as you go.</p>
          </div>
          <button
            onClick={onStart}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-stone-900 px-6 py-3 font-semibold hover:bg-stone-800 transition text-white whitespace-nowrap"
          >
            Begin Module 1 <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>
    </div>
  );
}
