import type { Lesson } from '../types';
import LessonContentView from './LessonContentView';
import { CheckCircle2, Clock, ArrowRight, ArrowLeft, ListChecks } from 'lucide-react';

interface Props {
  lesson: Lesson;
  moduleTitle: string;
  moduleIndex: number;
  lessonIndex: number;
  lessonCount: number;
  isComplete: boolean;
  onMarkComplete: () => void;
  onPrev?: () => void;
  onNext?: () => void;
  nextLabel?: string;
}

export default function LessonView({
  lesson,
  moduleTitle,
  moduleIndex,
  lessonIndex,
  lessonCount,
  isComplete,
  onMarkComplete,
  onPrev,
  onNext,
  nextLabel,
}: Props) {
  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <p className="text-xs font-semibold text-orange-500 uppercase tracking-wide mb-2">
        Module {moduleIndex + 1}: {moduleTitle} · Lesson {lessonIndex + 1} of {lessonCount}
      </p>
      <h1 className="text-3xl font-extrabold text-stone-900 mb-3">{lesson.title}</h1>
      <div className="flex items-center gap-2 text-sm text-stone-500 mb-8">
        <Clock className="h-4 w-4" /> {lesson.minutes} min read
        {isComplete && (
          <span className="inline-flex items-center gap-1 text-emerald-600 font-medium ml-2">
            <CheckCircle2 className="h-4 w-4" /> Completed
          </span>
        )}
      </div>

      <LessonContentView blocks={lesson.blocks} />

      <div className="mt-10 rounded-2xl border border-stone-200 bg-stone-50 p-5">
        <div className="flex items-center gap-2 font-bold text-stone-800 mb-3">
          <ListChecks className="h-5 w-5 text-orange-500" /> Key takeaways
        </div>
        <ul className="space-y-1.5">
          {lesson.keyTakeaways.map((kt, i) => (
            <li key={i} className="flex gap-2 text-sm text-stone-700">
              <span className="text-orange-500 mt-0.5">•</span>
              <span>{kt}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 justify-between">
        <button
          onClick={onPrev}
          disabled={!onPrev}
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 px-5 py-2.5 text-sm font-semibold text-stone-600 hover:bg-stone-100 transition disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ArrowLeft className="h-4 w-4" /> Previous
        </button>

        {!isComplete ? (
          <button
            onClick={onMarkComplete}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600 transition"
          >
            <CheckCircle2 className="h-4 w-4" /> Mark complete
          </button>
        ) : (
          <button
            onClick={onNext}
            disabled={!onNext}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600 transition disabled:opacity-30 disabled:cursor-not-allowed"
          >
            {nextLabel || 'Next'} <ArrowRight className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}
