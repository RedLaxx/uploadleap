import type { ContentBlock } from '../types';
import { Lightbulb, AlertTriangle, Quote as QuoteIcon, ThumbsDown, ThumbsUp } from 'lucide-react';

export default function LessonContentView({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <div className="space-y-5">
      {blocks.map((block, i) => {
        switch (block.type) {
          case 'heading':
            return (
              <h3 key={i} className="text-xl font-bold text-stone-800 mt-6">
                {block.text}
              </h3>
            );
          case 'paragraph':
            return (
              <p key={i} className="leading-relaxed text-stone-700">
                {block.text}
              </p>
            );
          case 'list':
            return block.ordered ? (
              <ol key={i} className="list-decimal list-outside pl-5 space-y-2 text-stone-700">
                {block.items.map((item, j) => (
                  <li key={j} className="leading-relaxed">{item}</li>
                ))}
              </ol>
            ) : (
              <ul key={i} className="list-disc list-outside pl-5 space-y-2 text-stone-700">
                {block.items.map((item, j) => (
                  <li key={j} className="leading-relaxed">{item}</li>
                ))}
              </ul>
            );
          case 'tip':
            return (
              <div key={i} className="flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
                <Lightbulb className="h-5 w-5 shrink-0 text-amber-500 mt-0.5" />
                <div>
                  {block.title && <p className="font-semibold text-amber-900 mb-1">{block.title}</p>}
                  <p className="text-amber-900/90 text-sm leading-relaxed">{block.text}</p>
                </div>
              </div>
            );
          case 'warning':
            return (
              <div key={i} className="flex gap-3 rounded-xl border border-rose-200 bg-rose-50 p-4">
                <AlertTriangle className="h-5 w-5 shrink-0 text-rose-500 mt-0.5" />
                <div>
                  {block.title && <p className="font-semibold text-rose-900 mb-1">{block.title}</p>}
                  <p className="text-rose-900/90 text-sm leading-relaxed">{block.text}</p>
                </div>
              </div>
            );
          case 'code':
            return (
              <div key={i} className="rounded-xl overflow-hidden border border-stone-700/20">
                {block.caption && (
                  <div className="bg-stone-800 px-4 py-1.5 text-xs text-stone-300 font-mono">{block.caption}</div>
                )}
                <pre className="bg-stone-900 text-stone-100 p-4 overflow-x-auto text-sm leading-relaxed">
                  <code>{block.code}</code>
                </pre>
              </div>
            );
          case 'compare':
            return (
              <div key={i} className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-rose-200 bg-rose-50/70 p-4">
                  <div className="flex items-center gap-2 text-rose-700 font-semibold text-sm mb-2">
                    <ThumbsDown className="h-4 w-4" /> Vague prompt
                  </div>
                  <p className="text-sm text-stone-700 italic">"{block.bad}"</p>
                </div>
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4">
                  <div className="flex items-center gap-2 text-emerald-700 font-semibold text-sm mb-2">
                    <ThumbsUp className="h-4 w-4" /> Specific prompt
                  </div>
                  <p className="text-sm text-stone-700 italic">"{block.good}"</p>
                </div>
              </div>
            );
          case 'quote':
            return (
              <div key={i} className="flex gap-3 border-l-4 border-orange-300 bg-orange-50/60 p-4 rounded-r-xl">
                <QuoteIcon className="h-5 w-5 shrink-0 text-orange-400" />
                <div>
                  <p className="italic text-stone-700 leading-relaxed">{block.text}</p>
                  {block.author && <p className="text-xs text-stone-500 mt-1">— {block.author}</p>}
                </div>
              </div>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}
