import { useState } from 'react';
import { labScenarios } from '../data/promptLab';
import { FlaskConical, Eye, EyeOff, ThumbsUp, ThumbsDown, CheckCircle2 } from 'lucide-react';

export default function PromptLab() {
  const [activeId, setActiveId] = useState(labScenarios[0].id);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [guesses, setGuesses] = useState<Record<string, 'good' | 'bad' | null>>({});

  const active = labScenarios.find((s) => s.id === activeId)!;

  const reveal = (id: string) => setRevealed((r) => ({ ...r, [id]: true }));

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <div className="flex items-center gap-2 mb-2 text-amber-600">
        <FlaskConical className="h-5 w-5" />
        <p className="text-xs font-bold uppercase tracking-wide">Interactive</p>
      </div>
      <h1 className="text-3xl font-extrabold text-stone-900 mb-3">Prompt Lab</h1>
      <p className="text-stone-600 mb-8 max-w-2xl">
        Practice spotting the difference between weak and strong prompts. Pick a scenario, guess which version of the
        prompt would work better, then reveal the breakdown to see why.
      </p>

      <div className="flex flex-wrap gap-2 mb-8">
        {labScenarios.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveId(s.id)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium border transition ${
              activeId === s.id
                ? 'bg-stone-900 text-white border-stone-900'
                : 'border-stone-300 text-stone-600 hover:border-orange-300 hover:bg-orange-50'
            }`}
          >
            {s.title}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border border-stone-200 bg-white p-6 mb-6">
        <p className="text-sm font-semibold text-stone-500 mb-1">Scenario</p>
        <p className="text-stone-800 leading-relaxed">{active.task}</p>
      </div>

      {!revealed[active.id] ? (
        <div className="rounded-2xl border border-dashed border-orange-300 bg-orange-50/50 p-6 text-center">
          <p className="text-stone-700 mb-4">
            Which approach do you think gets a better result? Make a guess, then reveal the analysis.
          </p>
          <div className="flex justify-center gap-3 mb-4">
            <button
              onClick={() => setGuesses((g) => ({ ...g, [active.id]: 'bad' }))}
              className={`rounded-xl border px-5 py-2.5 text-sm font-semibold transition ${
                guesses[active.id] === 'bad' ? 'border-rose-400 bg-rose-50 text-rose-700' : 'border-stone-300 hover:bg-stone-50'
              }`}
            >
              Prompt A is better
            </button>
            <button
              onClick={() => setGuesses((g) => ({ ...g, [active.id]: 'good' }))}
              className={`rounded-xl border px-5 py-2.5 text-sm font-semibold transition ${
                guesses[active.id] === 'good' ? 'border-emerald-400 bg-emerald-50 text-emerald-700' : 'border-stone-300 hover:bg-stone-50'
              }`}
            >
              Prompt B is better
            </button>
          </div>
          <div className="grid sm:grid-cols-2 gap-3 text-left mb-4">
            <div className="rounded-xl bg-white border border-stone-200 p-4">
              <p className="text-xs font-bold text-stone-400 mb-2">PROMPT A</p>
              <p className="text-sm italic text-stone-700">"{active.badPrompt}"</p>
            </div>
            <div className="rounded-xl bg-white border border-stone-200 p-4">
              <p className="text-xs font-bold text-stone-400 mb-2">PROMPT B</p>
              <p className="text-sm italic text-stone-700">"{active.goodPrompt}"</p>
            </div>
          </div>
          <button
            onClick={() => reveal(active.id)}
            disabled={!guesses[active.id]}
            className="inline-flex items-center gap-2 rounded-xl bg-stone-900 text-white px-5 py-2.5 text-sm font-semibold hover:bg-stone-800 transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Eye className="h-4 w-4" /> Reveal analysis
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {guesses[active.id] === 'good' ? (
            <div className="flex items-center gap-2 text-emerald-700 font-semibold">
              <CheckCircle2 className="h-5 w-5" /> Correct instinct — Prompt B (the specific one) wins.
            </div>
          ) : (
            <div className="flex items-center gap-2 text-amber-700 font-semibold">
              Good guess, but Prompt B (the specific one) is actually the stronger choice here. Here's why:
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-5">
              <div className="flex items-center gap-2 text-rose-700 font-bold text-sm mb-2">
                <ThumbsDown className="h-4 w-4" /> Prompt A (weak)
              </div>
              <p className="text-sm italic text-stone-700 mb-3">"{active.badPrompt}"</p>
              <p className="text-sm text-stone-600 leading-relaxed">{active.badWhy}</p>
            </div>
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-5">
              <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm mb-2">
                <ThumbsUp className="h-4 w-4" /> Prompt B (strong)
              </div>
              <p className="text-sm italic text-stone-700 mb-3">"{active.goodPrompt}"</p>
              <p className="text-sm text-stone-600 leading-relaxed">{active.goodWhy}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {active.tags.map((t) => (
              <span key={t} className="rounded-full bg-stone-100 text-stone-500 text-xs px-3 py-1 font-medium">
                #{t}
              </span>
            ))}
          </div>
          <button
            onClick={() => setRevealed((r) => ({ ...r, [active.id]: false }))}
            className="inline-flex items-center gap-2 text-sm text-stone-500 hover:text-stone-700"
          >
            <EyeOff className="h-4 w-4" /> Hide analysis
          </button>
        </div>
      )}
    </div>
  );
}
