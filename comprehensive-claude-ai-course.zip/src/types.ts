// Core content types for the Claude AI Mastery course

export type ContentBlock =
  | { type: 'heading'; text: string }
  | { type: 'paragraph'; text: string }
  | { type: 'list'; items: string[]; ordered?: boolean }
  | { type: 'tip'; title?: string; text: string }
  | { type: 'warning'; title?: string; text: string }
  | { type: 'code'; code: string; language?: string; caption?: string }
  | { type: 'compare'; good: string; bad: string }
  | { type: 'quote'; text: string; author?: string };

export interface Lesson {
  id: string;
  title: string;
  minutes: number;
  blocks: ContentBlock[];
  keyTakeaways: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  passPercent: number;
  questions: QuizQuestion[];
}

export interface Module {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  lessons: Lesson[];
  quiz: Quiz;
}

export interface LabScenario {
  id: string;
  title: string;
  task: string;
  badPrompt: string;
  badWhy: string;
  goodPrompt: string;
  goodWhy: string;
  tags: string[];
}

export type ProgressState = {
  completedLessons: Record<string, boolean>;
  quizScores: Record<string, number>;
  quizPassed: Record<string, boolean>;
  finalExamScore: number | null;
  finalExamPassed: boolean;
  studentName: string;
};
