import { useCallback, useEffect, useState } from 'react';
import type { ProgressState } from '../types';

const STORAGE_KEY = 'claude-course-progress-v1';

const defaultProgress: ProgressState = {
  completedLessons: {},
  quizScores: {},
  quizPassed: {},
  finalExamScore: null,
  finalExamPassed: false,
  studentName: '',
};

function loadProgress(): ProgressState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProgress;
    const parsed = JSON.parse(raw);
    return { ...defaultProgress, ...parsed };
  } catch {
    return defaultProgress;
  }
}

export function useProgress() {
  const [progress, setProgress] = useState<ProgressState>(loadProgress);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  const markLessonComplete = useCallback((lessonId: string) => {
    setProgress((p) => ({
      ...p,
      completedLessons: { ...p.completedLessons, [lessonId]: true },
    }));
  }, []);

  const recordQuizResult = useCallback((quizId: string, percent: number, passed: boolean) => {
    setProgress((p) => ({
      ...p,
      quizScores: { ...p.quizScores, [quizId]: percent },
      quizPassed: { ...p.quizPassed, [quizId]: passed },
    }));
  }, []);

  const recordFinalExam = useCallback((percent: number, passed: boolean) => {
    setProgress((p) => ({ ...p, finalExamScore: percent, finalExamPassed: passed }));
  }, []);

  const setStudentName = useCallback((name: string) => {
    setProgress((p) => ({ ...p, studentName: name }));
  }, []);

  const resetProgress = useCallback(() => {
    setProgress(defaultProgress);
  }, []);

  return { progress, markLessonComplete, recordQuizResult, recordFinalExam, setStudentName, resetProgress };
}
