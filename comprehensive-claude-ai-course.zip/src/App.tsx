import { useMemo, useState } from 'react';
import { modules } from './data/modules';
import { finalExam } from './data/finalExam';
import { useProgress } from './hooks/useProgress';
import Sidebar, { type Selection } from './components/Sidebar';
import Landing from './components/Landing';
import LessonView from './components/LessonView';
import QuizView from './components/QuizView';
import PromptLab from './components/PromptLab';
import Certificate from './components/Certificate';
import TopProgress from './components/TopProgress';
import { RotateCcw } from 'lucide-react';

type Unit = { type: 'lesson'; moduleId: string; lessonId: string } | { type: 'quiz'; moduleId: string };

function buildUnits(): Unit[] {
  const units: Unit[] = [];
  for (const mod of modules) {
    for (const lesson of mod.lessons) {
      units.push({ type: 'lesson', moduleId: mod.id, lessonId: lesson.id });
    }
    units.push({ type: 'quiz', moduleId: mod.id });
  }
  return units;
}

const UNITS = buildUnits();

export default function App() {
  const [selection, setSelection] = useState<Selection>({ kind: 'landing' });
  const { progress, markLessonComplete, recordQuizResult, recordFinalExam, setStudentName, resetProgress } =
    useProgress();

  const allModulesDone = modules.every(
    (m) => m.lessons.every((l) => progress.completedLessons[l.id]) && progress.quizPassed[m.quiz.id]
  );

  const unitIndex = useMemo(() => {
    if (selection.kind === 'lesson') {
      return UNITS.findIndex((u) => u.type === 'lesson' && u.moduleId === selection.moduleId && u.lessonId === selection.lessonId);
    }
    if (selection.kind === 'quiz') {
      return UNITS.findIndex((u) => u.type === 'quiz' && u.moduleId === selection.moduleId);
    }
    return -1;
  }, [selection]);

  function goToUnit(idx: number) {
    if (idx < 0) return;
    if (idx >= UNITS.length) {
      setSelection({ kind: 'final' });
      return;
    }
    const u = UNITS[idx];
    if (u.type === 'lesson') setSelection({ kind: 'lesson', moduleId: u.moduleId, lessonId: u.lessonId });
    else setSelection({ kind: 'quiz', moduleId: u.moduleId });
  }

  let body: React.ReactNode = null;

  if (selection.kind === 'landing') {
    body = (
      <Landing
        studentName={progress.studentName}
        onNameChange={setStudentName}
        onStart={() => setSelection({ kind: 'lesson', moduleId: modules[0].id, lessonId: modules[0].lessons[0].id })}
      />
    );
  } else if (selection.kind === 'lesson') {
    const mod = modules.find((m) => m.id === selection.moduleId)!;
    const modIndex = modules.findIndex((m) => m.id === mod.id);
    const lessonIndex = mod.lessons.findIndex((l) => l.id === selection.lessonId);
    const lesson = mod.lessons[lessonIndex];
    const isComplete = !!progress.completedLessons[lesson.id];
    const nextUnit = UNITS[unitIndex + 1];
    body = (
      <LessonView
        key={lesson.id}
        lesson={lesson}
        moduleTitle={mod.title}
        moduleIndex={modIndex}
        lessonIndex={lessonIndex}
        lessonCount={mod.lessons.length}
        isComplete={isComplete}
        onMarkComplete={() => markLessonComplete(lesson.id)}
        onPrev={unitIndex > 0 ? () => goToUnit(unitIndex - 1) : undefined}
        onNext={() => goToUnit(unitIndex + 1)}
        nextLabel={nextUnit?.type === 'quiz' ? 'Take module quiz' : 'Next lesson'}
      />
    );
  } else if (selection.kind === 'quiz') {
    const mod = modules.find((m) => m.id === selection.moduleId)!;
    const modIndex = modules.findIndex((m) => m.id === mod.id);
    const isLastModule = modIndex === modules.length - 1;
    body = (
      <div className="max-w-3xl mx-auto px-6 py-10">
        <p className="text-xs font-semibold text-orange-500 uppercase tracking-wide mb-2">
          Module {modIndex + 1}: {mod.title}
        </p>
        <QuizView
          key={mod.quiz.id}
          quiz={mod.quiz}
          onComplete={(pct, passed) => recordQuizResult(mod.quiz.id, pct, passed)}
          onContinue={() => (isLastModule ? setSelection({ kind: 'final' }) : goToUnit(unitIndex + 1))}
          continueLabel={isLastModule ? 'Go to Final Exam' : 'Continue to next module'}
        />
      </div>
    );
  } else if (selection.kind === 'lab') {
    body = <PromptLab />;
  } else if (selection.kind === 'final') {
    body = (
      <div className="max-w-3xl mx-auto px-6 py-10">
        <p className="text-xs font-semibold text-orange-500 uppercase tracking-wide mb-2">Capstone Assessment</p>
        <QuizView
          quiz={finalExam}
          onComplete={(pct, passed) => recordFinalExam(pct, passed)}
          onContinue={() => setSelection({ kind: 'certificate' })}
          continueLabel="Claim your certificate"
        />
      </div>
    );
  } else if (selection.kind === 'certificate') {
    body = <Certificate progress={progress} allModulesDone={allModulesDone} onNameChange={setStudentName} />;
  }

  return (
    <div className="flex min-h-screen bg-stone-50">
      <Sidebar selection={selection} onSelect={setSelection} progress={progress} />
      <div className="flex-1 min-w-0">
        {selection.kind !== 'landing' && (
          <div className="sticky top-0 z-10 bg-stone-50/90 backdrop-blur border-b border-stone-200 px-6 py-3 flex items-center gap-4">
            <TopProgress progress={progress} />
            <button
              onClick={() => {
                if (confirm('Reset all course progress? This cannot be undone.')) resetProgress();
              }}
              className="inline-flex items-center gap-1.5 text-xs text-stone-400 hover:text-rose-500 transition whitespace-nowrap"
              title="Reset progress"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
          </div>
        )}
        <main>{body}</main>
      </div>
    </div>
  );
}
